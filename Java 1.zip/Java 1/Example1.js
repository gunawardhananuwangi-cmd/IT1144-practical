function buy(product){
	alert(product+"  selected");}

function great(){
	alert("HELLO");
}